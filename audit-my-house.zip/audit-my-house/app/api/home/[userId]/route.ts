import mongoose from "mongoose";
import { z } from "zod";
import type { NextApiRequest, NextApiResponse } from "next";
import { NextRequest, NextResponse } from "next/server";
import clientPromise from "../../../../lib/mongodb";
import { UpdatedUserValidator } from "@/modals/userValidator";
import { updateUser } from "../helper";
import User from "@/modals/User";
import { connectToDB } from "@/lib/db";

type ParamsType = { params: { userId: any } };

// (async function () {
//   await connectToDB();
// })();

export async function PUT(req: Request, { params }: ParamsType) {
  try {
    const body = await req.json();
    const id = params.userId;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ message: "Invalid item ID" }, { status: 400 });
    }

    const user: typeof UpdatedUserValidator = body;
    const validation = UpdatedUserValidator.safeParse(user);
    if (!validation.success) {
      const errResponse = validation.error.issues[0];
      return NextResponse.json({ error: errResponse }, { status: 400 });
    }

    if (!id) {
      return NextResponse.json(
        { message: "User Id is Required" },
        { status: 400 }
      );
    }
    const updatedUser = await User.findByIdAndUpdate(id, user, { new: true });
    console.log("updatedUser", updatedUser);
    if (!updatedUser) {
      return NextResponse.json(
        { id, message: "User not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      message: "User updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.log(error.errors);
      return NextResponse.json({
        status: 400,
        message: "Invaid Input",
        error: error.errors,
      });
    }
    return NextResponse.json({
      status: 400,
      message: "Invaid Input",
      error: error,
    });
  }
}

export async function DELETE(req: Request, { params }: ParamsType) {
  try {
    const id: string = params.userId;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ message: "Invalid User ID" }, { status: 400 });
    }

    if (!id) {
      return NextResponse.json(
        { message: "User Id is Required" },
        { status: 400 }
      );
    }
    const deletedUser = await User.findByIdAndDelete(id);
    console.log("deletedUser", deletedUser);
    if (!deletedUser) {
      return NextResponse.json(
        { id, message: "User not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      message: "User Deleted successfully",
      user: deletedUser,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.log(error.errors);
      return NextResponse.json({
        status: 400,
        message: "Invaid Input",
        error: error.errors,
      });
    }
    return NextResponse.json({
      status: 400,
      message: "Invaid Input",
      error: error,
    });
  }
}
