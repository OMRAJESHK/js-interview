import type { NextApiRequest, NextApiResponse } from "next";
import { NextRequest, NextResponse } from "next/server";
import clientPromise from "../../../lib/mongodb";
import { UserValidator, type UserType } from "@/modals/userValidator";
import { z } from "zod";
import { getUpdatedUser, insertUser, updateUser } from "./helper";
import { type ObjectId } from "mongodb";
import { connectToDB } from "@/lib/db";
import User from "@/modals/User";

type ResponseData = { message: string };

export async function GET(
  req: NextApiRequest,
  res: NextApiResponse<ResponseData>
) {
  await connectToDB();
  try {
    const users = await User.find();
    return NextResponse.json({ data: users }, { status: 200 });
  } catch (e) {
    console.error(e);
  }
}

export async function POST(req: NextRequest) {
  const body: UserType = await req.json();

  try {
    await connectToDB();
    const user = await getUpdatedUser(body);

    const validation = UserValidator.safeParse(user);
    if (!validation.success) {
      return NextResponse.json(validation.error.format());
    }
    const response = await insertUser(user);
    // console.log(response);
    console.log("response123456=>", response);

    return NextResponse.json(
      {
        message: "User Added Successfully",
        data: response,
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.log(error.errors);
    }
    return NextResponse.json(
      {
        message: "User Not Saved",
        error: error,
      },
      { status: 500 }
    );
  }
}
