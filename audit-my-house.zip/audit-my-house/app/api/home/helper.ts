import { type ObjectId } from "mongodb";
import clientPromise from "../../../lib/mongodb";
import { type UserType } from "@/modals/userValidator";
import bcrypt from "bcryptjs";
import User from "@/modals/User";

export async function getUpdatedUser(body: UserType) {
  const user: UserType = {
    ...body,
    created_date: new Date(),
  };

  const salt = await bcrypt.genSalt(10);
  user.password = await bcrypt.hash(user.password, salt);
  return user;
}

export async function insertUser(user: UserType) {
  const createUser = new User(user);
  const response = await createUser.save();
  // const db = clientPromise.db(process.env.DB_NAME);
  // const collection = db.collection("users");
  // const response = await collection.insertOne(user);
  return response;
}

export async function updateUser(id: ObjectId, user: UserType) {
  const db = clientPromise.db(process.env.DB_NAME);
  const collection = db.collection("users");

  const response = await User.findByIdAndUpdate(id, { user }, { new: true });

  // const response = await collection.updateOne(
  //   { _id: id },
  //   { $set: { ...user } }
  // );

  console.log("response=>", response);
  return response;
}
